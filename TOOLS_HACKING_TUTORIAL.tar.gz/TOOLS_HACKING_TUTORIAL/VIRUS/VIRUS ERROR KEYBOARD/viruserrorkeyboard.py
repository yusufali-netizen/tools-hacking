import pyautogui
import time

while True:
    pyautogui.moveTo(200, 100, duration=0.5)
    time.sleep(3)
    pyautogui.press('a')


