import hashlib
import time


counter = 1

md5_hash = input("masukan md5: ")
pwdfile = input("alamat wordlist: ")

try:
	pwdfile = open(pwdfile, "r")
except:
	print("\nfile tidak ada")

for password in pwdfile:
	md5 = hashlib.md5()
	md5.update(password.strip().encode('ascii'))
	start = time.time()
	print("coba password %d: %s" % (counter,password.strip()))

	counter += 1
	end = time.time()
	t_time = end - start 

	if md5_hash.strip() == md5.hexdigest():
		print("\npassword ditemukan \npasswordnya adalah : %s" % password.strip())
		print("total waktu: ", t_time, "second")
		time.sleep(10)
		break
	else:
		print("password tidak ditemukan")