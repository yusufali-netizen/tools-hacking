import hashlib # untuk mendekrip
from time import sleep # untuk jeda waktu

def convert_text_to_sha1(text):
	digest = hashlib.md5(text.encode()).hexdigest()
	return digest

def main():
	user_sha1 = input("masukan md5 untuk di decrypt/crack ygy:")
	cleaned_user_sha1 = user_sha1.strip().lower()
	with open('./wordlist.txt') as f:
		for line in f:
			password = line.strip()
			converted_sha1 = convert_text_to_sha1(password)
			if cleaned_user_sha1 == converted_sha1:
				print("password telah ditemukan yoai", password)
			else:
				print("password masih di cari mohon bersabar anjoy")
				sleep(1)

if __name__ == '__main__':
	main()
