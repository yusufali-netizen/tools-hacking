import pikepdf
from time import sleep
from termcolor import colored
from tqdm import tqdm

file_pdf = input("masukan file pdf kalian ygy:")
wordlist = input("masukan file wordlist kalian ygy:")
passwords = [line.strip()for line in open(wordlist)] # membaca isi dalaman wordlist secara diulang ulang
n_words = len(list(open(wordlist, "rb"))) # menghitung jumlah kata didalam wordlist

sleep(1)
print("total password :", n_words)
sleep(1)

for password in tqdm(passwords, "decrypting pdf"):
	try:
		with pikepdf.open(file_pdf, password=password) as pdf:
			print(colored(("[+] password ditemukan", password, "[+]"), "green"))
			break 
	except pikepdf.PasswordError as e:
		continue
