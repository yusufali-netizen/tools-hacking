import zipfile, os
from time import sleep
from tqdm import tqdm
from termcolor import colored

file_zip = input("masukan file pdf yang ingin di crack:")
wordlist = input("masukan file wordlist yang akan digunakan:")
passwords = [line.strip()for line in open(wordlist)]
n_words = len(list(open(wordlist, "rb")))

sleep(1)
print("[+]total password test[+]" ,n_words,"[+]")
sleep(1)

for password in tqdm(passwords, "[+]Decrypting zip"):
	try:
		with zipfile.open(file_zip, password=password) as zip:
			print(colored(("[+] password ditemukan", password, "[+]"), "green"))
			break
	except zipfile.PasswordError as e:
		continue
