import string
import random

jumlah = int(input("masukan jumlah:"))

karakter = string.ascii_letters # huruf
karakter += string.digits # angka
karakter += string.punctuation # simbol

password = ''.join([random.choice(karakter) for i in range(jumlah)])

#for i in range(jumlah):
	#password += random.choice(karakter)

print("password acak elu adalah:", password)


