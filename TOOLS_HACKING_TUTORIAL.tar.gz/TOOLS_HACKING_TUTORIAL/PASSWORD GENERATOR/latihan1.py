import string
import random

jumlah = int(input("masukan jumlah:"))

karakter = string.ascii_letters # huruf
karakter += string.digits # angka
karakter += string.punctuation # simbol

print(karakter)


