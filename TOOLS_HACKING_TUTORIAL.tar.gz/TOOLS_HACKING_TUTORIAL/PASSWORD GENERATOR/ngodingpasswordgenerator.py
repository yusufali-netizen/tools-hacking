import string
import random

jumlah = int(input("masukan jumlah:"))

karakter = string.ascii_letters
karakter += string.digits
karakter += string.punctuation

#print(karakter)

password = ''.join([random.choice(karakter) for i in range(jumlah)])

#for i in range(jumlah):
	#plus_karakter = random.choice(karakter)
	#password += plus_karakter
	#password += random.choice(karakter)
	
print("password acak elu adalah:", password)
