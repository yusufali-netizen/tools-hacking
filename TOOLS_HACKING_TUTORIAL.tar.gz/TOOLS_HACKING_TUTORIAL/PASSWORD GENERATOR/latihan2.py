import string
import random

jumlah = int(input("masukan jumlah:"))

karakter = string.ascii_letters # huruf
karakter += string.digits # angka
karakter += string.punctuation # simbol

password = ""

for i in range(jumlah):
	plus_karakter = random.choice(karakter)
	password += plus_karakter

print("password acak elu adalah:", password)


