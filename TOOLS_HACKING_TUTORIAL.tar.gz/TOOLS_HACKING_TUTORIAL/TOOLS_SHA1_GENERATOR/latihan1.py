import hashlib # untuk mengenkripsi password kedalam bentuk enkripsi sesuai yang disediakan oleh modul

def Sha1():
	while True:
		string = input("masukan password ygy yg mau di encrypt sha1:")
		Hashlib = hashlib.sha1(string.encode()).hexdigest()
		print("password udah di encrypt", Hashlib)
		break

Sha1()