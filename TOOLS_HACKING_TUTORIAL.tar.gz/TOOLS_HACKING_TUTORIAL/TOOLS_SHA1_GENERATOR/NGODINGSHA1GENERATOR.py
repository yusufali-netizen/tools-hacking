import hashlib

def Sha1():
	while True:
		string = input("masukan kata untuk di hash:")
		sha1_hash = hashlib.sha1(string.encode()).hexdigest()
		print("SHA1 Hash adalah:", sha1_hash)
		break

Sha1()