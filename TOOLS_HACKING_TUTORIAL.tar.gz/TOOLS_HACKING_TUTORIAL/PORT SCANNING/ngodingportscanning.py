import socket
from termcolor import colored

def scan(ipaddress, port):
	try:
		sock = socket.socket()
		sock.connect((ipaddress, port))
		service = sock.recv(1024)
		service = service.decode('utf-8')
		service = service.strip('\n')
		portcolor = f'Port {str(port)} is open'
		print(colored(portcolor, 'green'), end='   ')
		print(service)
	except ConnectionRefusedError:
		print(colored(f'Port {str(port)} closed', 'red'))
	except UnicodeDecodeError:
		print(colored(f'Port {str(port)} open', 'yellow'))
		
target = input('Target:')
ports = input('Port:')

if ',' in ports:
	portlist = ports.split(',')
	for port in portlist:
		scan(target, int(port))
elif '-' in ports:
	portrange = ports.split('-')
	start = int(portrange[0])
	end = int(portrange[1])
	for port in range(start, end+1):
		scan(target, port)

else:
	scan(target, int(ports))
