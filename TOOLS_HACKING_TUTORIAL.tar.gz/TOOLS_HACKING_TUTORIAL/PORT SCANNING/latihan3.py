import socket

def scan(ipaddress, port):
	try:
		sock = socket.socket()
		sock.connect((ipaddress, port))
		print(f'port {str(port)} terbuka portnya boskyuuuu')
	except ConnectionRefusedError:
		print(f'port {str(port)} tertutup mamennnnnnnnnn')
		
target = input('ip target server:')
ports = input('port target server:')

if ',' in ports:
	portlist = ports.split(',')
	for port in portlist:
		scan(target, int(port))
else:
	scan(target, int(ports))