import socket
from termcolor import colored

def scan(ipaddress, port):
	try:
		sock = socket.socket()
		sock.connect((ipaddress, port))
		service = sock.recv(1024)
		service = service.decode('utf-8')
		service = service.strip('\n')
		portcolor = f'port {str(port)} terbuka'
		print(colored(portcolor, 'green'), end='  ')
		print(service)
	except ConnectionRefusedError:
		print(colored(f'port {str(port)} tertutup mamennnnnnnnnn', 'red'))
	except UnicodeDecodeError:
		print(colored(f'port {str(port)} terbuka', 'yellow'))
		
target = input('ip target server:')
ports = input('port target server:')

if ',' in ports:
	portlist = ports.split(',')
	for port in portlist:
		scan(target, int(port))
elif '-' in ports:
	portrange = ports.split('-')
	start = int(portrange[0])
	end = int(portrange[1])
	for port in range(start, end+1):
		scan(target, port)
else:
	scan(target, int(ports))