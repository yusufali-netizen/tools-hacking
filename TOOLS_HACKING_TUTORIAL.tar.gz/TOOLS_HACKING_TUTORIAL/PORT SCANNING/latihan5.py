import socket

def scan(ipaddress, port):
	try:
		sock = socket.socket()
		sock.connect((ipaddress, port))
		service = sock.recv(1024)
		print(f'port {str(port)} terbuka', end='  ')
		print(service)
	except ConnectionRefusedError:
		print(f'port {str(port)} tertutup mamennnnnnnnnn')
		
target = input('ip target server:')
ports = input('port target server:')

if ',' in ports:
	portlist = ports.split(',')
	for port in portlist:
		scan(target, int(port))
elif '-' in ports:
	portrange = ports.split('-')
	start = int(portrange[0])
	end = int(portrange[1])
	for port in range(start, end):
		scan(target, port)
else:
	scan(target, int(ports))