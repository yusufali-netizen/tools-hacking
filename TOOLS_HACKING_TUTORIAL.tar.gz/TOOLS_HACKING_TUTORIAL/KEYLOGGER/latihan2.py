from pynput import keyboard # digunakan untuk merekam aktifitas keyboard dengan fitur listener

keys_list = []

def key_pressed(key):
	try:
		keys_list.append(key)
		log_keys(keys_list)
	except:
		pass

def key_release(key):
	if key == keyboard.Key.esc:
		return False

def log_keys(list_of_keys):
	for k in list_of_keys:
		print(k)
		print(type(k))

with keyboard.Listener(on_press=key_pressed, on_release=key_release) as listener:
	listener.join()