from itertools import product 
import string

minimal_kata = int(input("masukan nilai minimal_kata ygy:"))
maksimal_kata = int(input("masukan nilai maksimal_kata ygy:"))

hasil_kata = 0
karakter = string.ascii_lowercase+string.ascii_uppercase+string.digits+string.punctuation

print(karakter)