from itertools import product 
import string

minimal_kata = int(input("masukan nilai minimal_kata ygy:"))
maksimal_kata = int(input("masukan nilai maksimal_kata ygy:"))

hasil_kata = 0
karakter = string.ascii_lowercase+string.ascii_uppercase+string.digits+string.punctuation

file_buka = open("wordlist.txt", 'w')

for i in range(minimal_kata,maksimal_kata+1):
	for j in product(karakter, repeat=i):
		kata = "".join(j)
		file_buka.write(kata)
		file_buka.write('\n')
		hasil_kata+=1

print("wordlistnya udah jadi ygy".format(file_buka))