import zipfile # untuk ngecrack pw
from time import sleep # untuk mengambil jeda supaya tidak bekerja berat laptop/pc
from tqdm import tqdm # menampilkan proges bar dari sebuah perulangan

zip_file = input("masukan file zip ingin di crack wokey:")
wordlist = input("masukan wordlist yang ingin kalian pake wokey:")

zip_file = zipfile.ZipFile(zip_file)
n_words = len(list(open(wordlist, "rb"))) # untuk mencetak isi password yang ada =didalam wordlist

sleep(1)
print("total password adalah:", n_words)
sleep(1)

with open(wordlist, "rb") as wordlist:
	for word in tqdm(wordlist, total=n_words, unit="word"):
		try:
			zipfile.extractall(pwd=word.strip())
		except:
			continue

print("password telah ditemukan:", word.decode().strip())
exit(0)
