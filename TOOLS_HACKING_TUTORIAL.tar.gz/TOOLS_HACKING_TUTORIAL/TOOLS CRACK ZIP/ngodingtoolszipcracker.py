import zipfile, os
import time
from time import sleep
from tqdm import tqdm

zip_file = input("masukan nama zip yang ingin di crack:")
wordlist = input("masukan wordlist:")

zip_file = zipfile.ZipFile(zip_file)
n_words = len(list(open(wordlist, "rb")))

sleep(1)
print("total password yang dipake buat crack:", n_words)
sleep(1)

with open(wordlist, "rb") as wordlist:
	for word in tqdm(wordlist, total=n_words, unit="word"):
		try:
			zip_file.extractall(pwd=word.strip())
		except:
			continue
print("password ditemukan:",word.decode().strip())
exit(0)